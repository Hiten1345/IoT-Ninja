# NinjaIoT Arduino Library

Arduino library for connecting ESP32 devices to the NinjaIoT platform.

## Installation

1. Download this library
2. In Arduino IDE, go to **Sketch > Include Library > Add .ZIP Library**
3. Select the downloaded library file

## API Changes (v2.0)

This library has been updated to work with the new API structure:

### New API Endpoints

- **Base URL**: `https://iot.roboninja.in/api/v1/{PROJECT_KEY}/`
- **Write Value**: `/write?field=value`
- **Read Specific Value**: `/read?field` (returns plain text)
- **Read Multiple Values**: `/read?fields=field1,field2` (returns JSON)
- **Read All Values**: `/read_all` (returns JSON)

### Migration from v1.0

**Old way (v1.0):**
```cpp
iot.connect("wifi-name", "wifi-pass", "UIDofIoTPlatform");
```

**New way (v2.0):**
```cpp
iot.connect("wifi-name", "wifi-pass", "Your_Project_API");  // Use your Project API Key
```

### Custom Base URL

If you need to use a different server or domain, you can specify a custom base URL:

```cpp
iot.connect("wifi-name", "wifi-pass", "Your_Project_API", "https://your-custom-domain.com/api/v1/");
```

## Quick Start

```cpp
#include <NinjaIoT.h>

NinjaIoT iot;

void setup() {
  Serial.begin(115200);
  iot.connect("your-wifi-name", "your-wifi-password", "Your_Project_API");
}

void loop() {
  iot.ReadAll();   // Read all values from the cloud
  iot.SyncOut("D27");  // Control LED on GPIO27 according to server value
  delay(50);
}
```

## Available Functions

### Connection
- `connect(ssid, password, projectKey)` - Connect to WiFi and set project key
- `connect(ssid, password, projectKey, baseURL)` - Connect with custom base URL

### Reading Data
- `ReadAll()` - Fetch all values from cloud and cache them (returns JSON string)
- `Read(field)` - Read a specific field value (returns plain text)
- `SyncVar(variable)` - Get variable value from cached JSON

### Writing Data
- `WriteVar(variable, value)` - Write a variable to the cloud (supports String, int, float)
- `SyncIN(field)` - Read digital pin state and upload to cloud
- `SyncOut(field)` - Set digital pin according to cloud value
- `SyncPWM(field)` - Set PWM output according to cloud value

## Pin Mapping (ESP32)

The library supports the following pins. Use these exact names when calling library functions:

| Pin Name | GPIO Pin | Notes |
|----------|----------|-------|
| D0       | GPIO0    | Boot button on some boards |
| D1       | GPIO1    | TX0 (Serial) |
| D2       | GPIO2    | Built-in LED on some boards |
| D3       | GPIO3    | RX0 (Serial) |
| D4       | GPIO4    |       |
| D5       | GPIO5    |       |
| D12      | GPIO12   | Boot fails if pulled high |
| D13      | GPIO13   |       |
| D14      | GPIO14   |       |
| D15      | GPIO15   | Boot fails if pulled high |
| D16      | GPIO16   |       |
| D17      | GPIO17   |       |
| D18      | GPIO18   |       |
| D19      | GPIO19   |       |
| D21      | GPIO21   |       |
| D22      | GPIO22   |       |
| D23      | GPIO23   |       |
| D25      | GPIO25   |       |
| D26      | GPIO26   |       |
| D27      | GPIO27   |       |
| D32      | GPIO32   | ADC1_CH4 |
| D33      | GPIO33   | ADC1_CH5 |
| D34      | GPIO34   | ADC1_CH6 (Input only) |
| D35      | GPIO35   | ADC1_CH7 (Input only) |
| VP       | GPIO36   | ADC1_CH0 (Input only) |
| VN       | GPIO39   | ADC1_CH3 (Input only) |

**Example Usage:**
```cpp
iot.SyncOut("D26");    // Control GPIO26
iot.SyncPWM("D27");    // PWM on GPIO27 (0-255)
iot.SyncIN("D14");     // Read GPIO14
iot.SyncIN("VP");      // Read VP (GPIO36) - analog capable
```

**Important Notes:** 
- PWM values for ESP32 range from 0-255 (8-bit resolution)
- GPIO34, 35, 36 (VP), 39 (VN) are **input-only** pins
- Avoid using D0, D1, D2, D3 if using Serial communication
- D12 and D15 can affect boot if pulled high

## Examples

Check the `examples` folder for:
- **01_Simple_LED** - Control an LED from the cloud
- **02_LED_Brightness_control** - PWM brightness control
- **03_Pin_State_to_cloud** - Upload button state
- **04_analogSensor_to_cloud** - Send analog sensor data
- **05_DHT11_to_cloud** - Temperature and humidity monitoring
- **allFunction** - Demonstrates all library functions

## Technical Notes

### Platform
- Designed for ESP32 boards
- Uses WiFi.h and HTTPClient.h (ESP32 standard libraries)
- WiFiClientSecure for HTTPS connections

### Hardware Specifications
- PWM resolution: 8-bit (0-255)
- Analog input pins (A0-A3/GPIO36,39,34,35) are input-only on ESP32
- ADC resolution: 12-bit (0-4095)

### API Changes
- Updated URL structure from query parameters to REST-style paths
- Project identification changed from `UID` to `projectKey`
- HTTPS with SSL certificate bypass for secure connections

### Performance
- The `Read(field)` method makes individual API calls for specific fields
- `ReadAll()` caches JSON for use with `SyncVar()`
- Rate limiting: 50ms delay between requests

## License

MIT License

## Support

For issues and questions, please visit: https://iot.roboninja.in/



