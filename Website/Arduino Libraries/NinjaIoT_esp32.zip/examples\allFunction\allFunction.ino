#include <NinjaIoT.h>

NinjaIoT iot;
int var = 0;

void setup() {
  Serial.begin(115200);
  iot.connect("wifi-name", "wifi-pass", "Your_Project_API");   // Use your Project API Key from https://iot.roboninja.in/
}

void loop() {
  var = random(0, 100);

  // This will fetch and cache all values once per loop cycle
  iot.ReadAll();

  // Control LED on GPIO27 according to server value (ON/OFF)
  iot.SyncOut("D27");

  // Adjust PWM brightness on GPIO14 from server value (0-255)
  iot.SyncPWM("D14");

  // Read button state on GPIO26 and upload it
  iot.SyncIN("D26");

  // Read Temperature variable from cached JSON
  String temp = iot.SyncVar("Temperature");
  Serial.println("Temperature from cloud: " + temp);

  // Write new Temperature value to cloud
  iot.WriteVar("Temperature", var);

  delay(2000);  // wait 2 seconds before next cycle
}



